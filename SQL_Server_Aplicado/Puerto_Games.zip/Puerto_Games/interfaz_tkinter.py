import tkinter as tk
from tkinter import obtener_videojuegos

#Obtener datos de la base de datos
datos= obtener_videojuegos()

# Crear una ventana
ventana = tk.Tk() 
ventana.title("Catalogo de Videojuegos") #Título de la ventana 
ventana.geometry("700x400") #Tamaño de la ventana

#Titulo
titulo = tk.Label(ventana, text="🎮Listado de Videojuegos🕹️", font=("Arial", 16, "bold"))
titulo.pack(pady=10) #Añadir el título a la ventana 

#Area de texto
texto = tk.Text(ventana, width=70, height=15, font=("Courier", 10))
texto.pack(pady=10) #Añadir el área de texto a la ventana 

#Mostrar los datos
for row in datos:
    nombre, genero, precio, plataforma = row
    texto.insert(tk.END, f"{nombre:25} | {genero:15} | {precio:8.0f} | {plataforma:15}\n")
    
#Boton cerrar
cerrar_btn = tk.Button(ventana, text="Cerrar", command=ventana.destroy)
cerrar_btn.pack(pady=10)

#Ejecutar la interfaz
ventana.mainloop()