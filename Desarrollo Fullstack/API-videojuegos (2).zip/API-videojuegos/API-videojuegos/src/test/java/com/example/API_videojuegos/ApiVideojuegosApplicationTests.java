package com.example.API_videojuegos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiVideojuegosApplicationTests {

	@Test
	void contextLoads() {
	}

}
