package com.example.API_videojuegos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiVideojuegosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiVideojuegosApplication.class, args);
	}

}
