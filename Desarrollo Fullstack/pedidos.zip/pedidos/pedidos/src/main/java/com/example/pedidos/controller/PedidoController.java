package com.example.pedidos.controller;

import com.example.pedidos.model.Pedido;
import com.example.pedidos.repository.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/pedidos")
public class PedidoController {
    @Autowired
    private PedidoRepository pedidorepository;

    @GetMapping
    public List<Pedido> getAllPedidos(){
        return pedidorepository.findAll();
    }

    @GetMapping("/{id}")
    public Optional<Pedido> getPedidoById(@PathVariable Long id) {
        return pedidorepository.findById(id);
    }

    @PostMapping
    public Pedido crearPedido(@RequestBody Pedido pedido){
        return pedidorepository.save(pedido);
    }

    @PutMapping("/{id}")
    public Pedido actualizarPedido(@PathVariable Long id, @RequestBody String estado) {
        Optional<Pedido> pedidoOptional = pedidorepository.findById(id);
        if (pedidoOptional.isPresent()) {
            Pedido pedido = pedidoOptional.get();
            pedido.setEstado(estado);
            return pedidorepository.save(pedido);
        }
        return null;
    }


}
